/*************************************************
*       Cube project version 1.2 
*
*	File description: 	Definition of basic data process function
*	File name:		struct_func.h
*	date:    	2015-08-23
*	Author:    	Hu jun
*************************************************/
#ifndef  STRUCT_FUNC_H
#define  STRUCT_FUNC_H



#endif
