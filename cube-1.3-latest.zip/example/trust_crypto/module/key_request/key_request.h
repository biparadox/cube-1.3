#ifndef KEY_REQUEST_H
#define KEY_REQUEST_H

int key_request_init(void * sub_proc,void * para);
int key_request_start(void * sub_proc,void * para);

#endif
