#ifndef KEY_REQUEST_H
#define KEY_REQUEST_H

int key_manage1_init(void * sub_proc,void * para);
int key_manage1_start(void * sub_proc,void * para);

#endif
