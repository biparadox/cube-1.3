#ifndef MSG_BROADCAST_H
#define MSG_BROADCAST_H


// plugin's init func and kickstart func
int msg_broadcast_init(void * sub_proc,void * para);
int msg_broadcast_start(void * sub_proc,void * para);

#endif
