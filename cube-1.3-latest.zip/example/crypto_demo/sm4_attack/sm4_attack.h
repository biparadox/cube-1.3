#ifndef FORCE_SM4_ATTACK_H
#define FORCE_SM4_ATTACK_H

// plugin's init func and kickstart func
int force_sm4_attack_init(void * sub_proc,void * para);
int force_sm4_attack_start(void * sub_proc,void * para);

#endif
