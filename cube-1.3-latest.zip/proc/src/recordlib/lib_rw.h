#ifndef LIB_RW_H
#define LIB_RW_H

int lib_read(int fd, int type,int subtype, void ** record)
int lib_write(int fd, int type,int subtype, void * record)

#endif
