
#ifndef AIK_PROCESS_FUNC_H
#define AIK_PROCESS_FUNC_H

int aik_manage_init(void * sub_proc,void * para);
int aik_manage_start(void * sub_proc,void * para);

#endif
