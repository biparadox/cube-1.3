#ifndef TPM_KEY_CREATE_H
#define TPM_KEY_CREATE_H

int tpm_key_create_init(void * sub_proc,void * para);
int tpm_key_create_start(void * sub_proc,void * para);

#endif
